
# project_1

Options trading involves financial contracts that provide the buyer the right, but not the obligation, to buy or sell an asset at a specified strike price before a specified expiration date. This tool allows users to retrieve option chain data for specific instruments (e.g., NIFTY or BANKNIFTY), and compute key metrics like the highest bid/ask price, margin required for selling options, and premium earned from selling the options.


## Key Concepts


Options Trading: A financial contract that allows the buyer to either buy (Call Option, CE) or sell (Put Option, PE) an asset at a specified strike price before the expiration date.

Strike Price: The price at which the option can be exercised. For example, if you buy a call option with a strike price of 19500, you have the right to buy at 19500, even if the market price is higher.

Expiry Date: The date when the option expires. After this date, the option can no longer be exercised.

Bid Price and Ask Price:

Bid Price: The highest price a buyer is willing to pay for an option.
Ask Price: The lowest price a seller is willing to accept for an option.
Option Selling: When you sell an option, you take on the obligation to buy (for Put options) or sell (for Call options) at the strike price if the buyer exercises the option.

Margin Requirements: Brokers require a margin to be deposited when selling options, as this involves higher risk. This margin requirement is calculated by APIs like Upstox or Fyers.

Premium Earned: When you sell an option, you earn a premium, calculated by multiplying the bid or ask price by the lot size (the number of units in one contract).
## Functionality

Part 1: Retrieve Option Chain Data
This part of the code retrieves option chain data for a given instrument (e.g., NIFTY or BANKNIFTY) on a specified expiry date. The function returns the highest bid price for Put Options (PE) or the highest ask price for Call Options (CE) for each strike price.

Function:

import pandas as pd
data = pd.read_excel(r'C:/Users/TUKARAM/OneDrive/Desktop/BreakoutAi_project/trade_data.xlsx');

data

	expiry_date	instrument_name	Amount	Exchange	Segment	Scrip Code	Instrument Type	Strike Price	Trade Num	Trade Time	side	Quantity	Price	bid/ask
0	2023-12-14	NIFTY	3662.05	NSE	EQ	532540	Equity	3662.05	60410955	09:19:18	CE	1	3662.05	3662.05
1	2023-12-12	NIFTY	1474.15	NSE	EQ	500209	Equity	1474.15	20162380	09:15:56	CE	1	1474.15	1474.15
2	2023-12-11	NIFTY	4150.00	BSE	EQ	532540	Equity	4150.00	6433387	00:00:00	CE	1	4150.00	4150.00
3	2023-12-11	NIFTY	160.80	NSE	EQ	530363	Equity	1278.85	63073818	10:54:32	PE	2	80.40	1278.85
4	2023-12-08	NIFTY	325.60	NSE	EQ	541956	Equity	438.30	21089222	09:35:36	PE	2	162.80	438.30
5	2023-12-07	NIFTY	1901.40	NSE	EQ	500547	Equity	61.60	644188	09:21:33	CE	4	475.35	61.60
6	2023-12-07	NIFTY	376.45	NSE	EQ	532810	Equity	1437.25	41737955	09:58:19	PE	1	376.45	1437.25
7	2023-12-07	NIFTY	246.40	NSE	EQ	533098	Equity	255.95	41797370	10:00:52	PE	4	61.60	255.95


data.shape

(8, 14)

data.info()

<class 'pandas.core.frame.DataFrame'>
RangeIndex: 8 entries, 0 to 7
Data columns (total 14 columns):
 #   Column           Non-Null Count  Dtype         
---  ------           --------------  -----         
 0   expiry_date      8 non-null      datetime64[ns]
 1   instrument_name  8 non-null      object        
 2   Amount           8 non-null      float64       
 3   Exchange         8 non-null      object        
 4   Segment          8 non-null      object        
 5   Scrip Code       8 non-null      int64         
 6   Instrument Type  8 non-null      object        
 7   Strike Price     8 non-null      float64       
 8   Trade Num        8 non-null      int64         
 9   Trade Time       8 non-null      object        
 10  side             8 non-null      object        
 11  Quantity         8 non-null      int64         
 12  Price            8 non-null      float64       
 13  bid/ask          8 non-null      float64       
dtypes: datetime64[ns](1), float64(4), int64(3), object(6)
memory usage: 1.0+ KB

   df = pd.DataFrame(data)

   df['bid/ask'] = df['bid/ask'].replace({'₹': '', ',': ''}, regex=True).astype(float)

   df['bid/ask'] = df['bid/ask'].replace({'₹': '', ',': ''}, regex=True).astype(float)

   highest_bid = df[df['side'] == 'PE']['bid/ask'].max()
highest_ask = df[df['side'] == 'CE']['bid/ask'].max()

highest_bid

np.float64(1437.25)

highest_ask

np.float64(4150.0)

df_filtered = df[(
    ((df['side'] == 'PE') & (df['bid/ask'] == highest_bid)) |
    ((df['side'] == 'CE') & (df['bid/ask'] == highest_ask))
)]

df_filtered[['expiry_date','Strike Price','side','bid/ask']]

expiry_date	Strike Price	side	bid/ask
2	2023-12-11	4150.00	CE	4150.00
6	2023-12-07	1437.25	PE	1437.25


Part 2: Calculate Margin and Premium Earned
This part calculates the margin required and the premium earned from the option data retrieved in Part 1.

Function:

import pandas as pd

data = pd.read_excel(r'C:/Users/TUKARAM/OneDrive/Desktop/BreakoutAi_project/trade_data.xlsx');

 df = pd.DataFrame(data)

 df['bid/ask'] = df['bid/ask'].replace({'₹': '', ',': ''}, regex=True).astype(float)

 df['bid/ask'] = df['bid/ask'].replace({'₹': '', ',': ''}, regex=True).astype(float)

 highest_bid = df[df['side'] == 'PE']['bid/ask'].max()
highest_ask = df[df['side'] == 'CE']['bid/ask'].max()

highest_bid

np.float64(1437.25)

highest_ask

np.float64(4150.0)

# Premium Earned=Premium×Lot Size
# Margin Required=Strike Price×Lot Size×Margin Percentage
# if Lot Size = 50
# and Margin Percentage  = 10%

def calculate_metrics(row, lot_size=50, margin_percentage=0.10):
    premium_earned = row['bid/ask'] * lot_size  # Premium Earned = premium * lot size
    margin_required = row['Strike Price'] * lot_size * margin_percentage  # Margin Required = strike price * lot size * margin percentage
    return pd.Series([premium_earned, margin_required])

 df[['premium_earned', 'margin_required']] = df.apply(calculate_metrics, axis=1)

df_filtered = df[(
    ((df['side'] == 'PE') & (df['bid/ask'] == highest_bid)) |
    ((df['side'] == 'CE') & (df['bid/ask'] == highest_ask))
)]

df_filtered[['expiry_date', 'Strike Price', 'side', 'bid/ask', 'premium_earned', 'margin_required']]

expiry_date	Strike Price	side	bid/ask	premium_earned	margin_required
2	2023-12-11	4150.00	CE	4150.00	207500.0	20750.00
6	2023-12-07	1437.25	PE	1437.25	71862.5	7186.25


## SAMPLE OUTPUT

 Part 1: Retrieve Option Chain Data 

	expiry_date	Strike Price	side	bid/ask
2	2023-12-11	4150.00	CE	4150.00
6	2023-12-07	1437.25	PE	1437.25

 Part 2: Calculate Margin and Premium Earned 

 	expiry_date	Strike Price	side	bid/ask	premium_earned	margin_required
2	2023-12-11	4150.00	CE	4150.00	207500.0	20750.00
6	2023-12-07	1437.25	PE	1437.25	71862.5	7186.25


